<?php
include "../conect.php";


$nome = "$_POST[nome]";
$cpf = "$_POST[cpf]";
$ddd = "$_POST[ddd]";
$telefone = "$_POST[telefone]";
$email = "$_POST[email]";
$rua = "$_POST[rua]";
$bairro = "$_POST[bairro]";
$complemento = "$_POST[complemento";
$cidade = "$_POST[cidade]";
$estado = "$_POST[estado]";
$cep = "$_POST[cep]";



$sql->query("INSERT INTO cliente(nome, cpf, contato, email)
VALUES ('$nome','$cpf','$contato','$email')");

$sql->query("INSERT INTO endereco(rua, bairro, complemento, cep, cidade, estado, cpf)
VALUES ('$rua','$bairro','$complemento','$cep','$cidade'.'$estado','$cpf')");

$sql->query("INSERT INTO contato(ddd, telefone, cpf)
VALUES ('$ddd','$telefone','$cpf')");


?>