<!doctype html>
<html lang="pt-br"> 
	<head>
		<meta charset="utf-8" />
		<title>Alterar Dados</title>
	</head> 
<body>
<?php
$id = $_GET ['id'];
include "../conect.php";
$sqld = mysqli_query($sql, "SELECT * FROM produto WHERE id = '$id'" ); 
while($coluna = mysqli_fetch_array($sqld)) {
     $id = $coluna['id'];
	 $quantidade = $coluna['quantidade'];
	 }
   

?>
<form action='update.php?id=$id' name='form' method='post'>
<center>
    <fieldset id='cadastro'>
        <legend> Atualizar Dados</legend>
   
		
  <div class="field">
            <label for="quantidade">M² Comprado:</label>
            <input type="number"  id="quantidade" placeholder="quantidade m²"  name="quantidade" required>
        </div>

<button>Atualizar</button>


        </form>
    </fieldset>
</center>

</BODY>
</HTML>
