<?php

$nome = "$_POST[nome]";
$cor = "$_POST[cor]";
$valor = "$_POST[valor]";
$quantidade = "$_POST[quantidade]";
$cnpj = "$_POST[cnpj]";
$fornecedor = "$_POST[fornecedor]";
$data_compra = "$_POST[data_compra]";

try{
    $con = new PDO("mysql:host=localhost;dbname=tcc", "root", "");
} catch (PDOException $e) {
    print "Erro: {$e->getMessage()}<br>";
    exit;
}
try{

    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $cadastro=$con->exec ("INSERT INTO produto(nome, cor, valor, quantidade, fornecedor, cnpj_fornecedor, data_compra) VALUES ('$nome','$cor','$valor','$quantidade', '$cnpj','$fornecedor', '$data_compra')");

} catch (PDOException $e){
   
   // $con->rollBack();

    print "Erro:{$e->getMessage()}<br>";
}
?>